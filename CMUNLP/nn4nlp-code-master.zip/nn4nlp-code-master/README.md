# Neural Networks for NLP Code Examples

This is a repository of code examples for the 2017 edition of CMU CS 11-747
[Neural Networks for NLP](http://phontron.com/class/nn4nlp2017/).

By Graham Neubig, Daniel Clothiaux, Zhengzhong Liu, and Xuezhe Ma
